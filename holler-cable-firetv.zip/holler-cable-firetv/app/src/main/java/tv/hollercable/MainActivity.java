package tv.hollercable;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Holler Cable on the Fire Stick: the web app full screen, with the remote wired in. */
public class MainActivity extends Activity {

    private WebView web;

    // ---- self-update: new lineup + new app versions from the GitHub releases ----
    private static final String RELEASES = "https://github.com/kennethcecil420/hollar-cable-firetv/releases/latest/download/";
    private static final long EVERY = 6L * 60 * 60 * 1000;      // check every 6 hours
    private static final String BASE_URL = "file:///android_asset/index.html?app=1";   // ?app=1 = power on to the last channel
    private final Handler ui = new Handler(Looper.getMainLooper());
    private long lastCheck = 0;
    private volatile boolean checking = false;
    private boolean resumed = false;
    private boolean reloadPending = false, installPending = false;
    private int loadedVersion = -1;      // which lineup version the TV is showing

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                   // remembers channel, favorites, TV settings
        s.setMediaPlaybackRequiresUserGesture(false);   // static + network jingles play right away
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true); // lets channel 3 pull live NWS weather

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return route(r.getUrl().toString());
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return route(url);
            }
        });

        setContentView(web);
        hideBars();
        loadLineup();
        checkForUpdates();
        ui.postDelayed(tick, EVERY);
    }

    private final Runnable tick = new Runnable() { public void run() { checkForUpdates(); ui.postDelayed(this, EVERY); } };

    private int appVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; } catch (Exception e) { return 0; }
    }
    private File lineupFile()  { return new File(getFilesDir(), "lineup.html"); }
    private File apkFile()     { return new File(getCacheDir(), "update.apk"); }
    private int savedLineupVersion() { return getSharedPreferences("hc", MODE_PRIVATE).getInt("lineup", -1); }

    /** Show the newest lineup we have: the downloaded one if it's at least as new as this app, else the built-in one. */
    private void loadLineup() {
        File f = lineupFile();
        int v = savedLineupVersion();
        if (f.exists() && v >= appVersion()) {
            try {
                String html = new String(readAll(new java.io.FileInputStream(f)), StandardCharsets.UTF_8);
                // same base URL as the built-in copy, so favorites and settings carry over
                web.loadDataWithBaseURL(BASE_URL, html, "text/html", "utf-8", null);
                loadedVersion = v;
                return;
            } catch (Exception ignored) { }
        }
        web.loadUrl(BASE_URL);
        loadedVersion = appVersion();
    }

    /** Asks GitHub for the latest build number; grabs the new lineup and/or the new app if there is one. */
    private void checkForUpdates() {
        if (checking) return;
        checking = true;
        lastCheck = System.currentTimeMillis();
        new Thread(() -> {
            try {
                int remote = Integer.parseInt(new String(get(RELEASES + "version.txt"), StandardCharsets.UTF_8).trim());
                // 1) new lineup: swap it in without reinstalling
                if (remote > Math.max(loadedVersion, savedLineupVersion())) {
                    byte[] html = get(RELEASES + "index.html");
                    String text = new String(html, StandardCharsets.UTF_8);
                    if (html.length > 50000 && text.contains("const CHANNELS")) {   // never swap in a broken page
                        File tmp = new File(getFilesDir(), "lineup.tmp");
                        try (OutputStream o = new FileOutputStream(tmp)) { o.write(html); }
                        if (tmp.renameTo(lineupFile())) {
                            getSharedPreferences("hc", MODE_PRIVATE).edit().putInt("lineup", remote).apply();
                            ui.post(() -> { reloadPending = true; if (resumed) applyPending(); });
                        }
                    }
                }
                // 2) new app version: download it, then offer to install
                if (remote > appVersion()) {
                    byte[] apk = get(RELEASES + "holler-cable.apk");
                    if (apk.length > 10000) {
                        try (OutputStream o = new FileOutputStream(apkFile())) { o.write(apk); }
                        ui.post(() -> { installPending = true; if (resumed) applyPending(); });
                    }
                }
            } catch (Exception ignored) {
                // no internet or GitHub hiccup: keep showing what we have, try again next time
            } finally {
                checking = false;
            }
        }).start();
    }

    /** Only reload or prompt while Holler Cable is on screen, never while a show is playing in another app. */
    private void applyPending() {
        if (reloadPending) {
            reloadPending = false;
            loadLineup();
            Toast.makeText(this, "Holler Cable lineup updated", Toast.LENGTH_LONG).show();
        }
        if (installPending) {
            installPending = false;
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                Toast.makeText(this, "One-time step: turn ON Holler Cable here so it can update itself, then press Back", Toast.LENGTH_LONG).show();
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                } catch (ActivityNotFoundException ignored) { }
                installPending = true;            // ask again when they come back
                return;
            }
            try {
                Intent i = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse("content://" + ApkProvider.AUTHORITY + "/update.apk"), ApkProvider.APK_TYPE)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Couldn't open the installer for the Holler Cable update", Toast.LENGTH_LONG).show();
            }
        }
    }

    private static byte[] get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setRequestProperty("Cache-Control", "no-cache");
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            return readAll(c.getInputStream());
        } finally { c.disconnect(); }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try (InputStream i = in; ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] buf = new byte[16384]; int n;
            while ((n = i.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        }
    }

    /** Every "WATCH" link lands here instead of loading inside the TV. */
    private boolean route(String url) {
        if (url.startsWith("file:") || url.startsWith("about:")) return false;
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "" : u.getHost();
        String path = u.getPath() == null ? "" : u.getPath();

        if (host.endsWith("archive.org") && path.startsWith("/details/")) {
            String id = path.substring("/details/".length()).split("/")[0];
            startActivity(new Intent(this, PlayerActivity.class).putExtra(PlayerActivity.EXTRA_ID, id));
            return true;
        }
        openExternal(u, host);
        return true;
    }

    private void openExternal(Uri u, String host) {
        String pkg = appFor(host);
        if (pkg != null) {
            // 1) ask the service's own app to open the exact title
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            } catch (ActivityNotFoundException ignored) { }
            // 2) at least open the app
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) launch = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
            if (launch != null) {
                startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                Toast.makeText(this, "Opened the app — search for the title there", Toast.LENGTH_LONG).show();
                return;
            }
        }
        // 3) whatever the stick wants to do with the link (usually Silk)
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app on this Fire Stick opens " + host, Toast.LENGTH_LONG).show();
        }
    }

    /** Finds the installed app for a service by name, so exact package IDs don't matter. */
    private String appFor(String host) {
        String[] keys;
        if (host.contains("netflix")) keys = new String[]{"com.netflix.ninja", "netflix"};
        else if (host.contains("peacock")) keys = new String[]{"peacock"};
        else if (host.contains("paramountplus")) keys = new String[]{"paramount", "com.cbs."};
        else if (host.contains("pluto.tv")) keys = new String[]{"pluto"};
        else if (host.contains("tubi")) keys = new String[]{"tubi"};
        else if (host.contains("hulu")) keys = new String[]{"com.hulu", "hulu"};
        else if (host.contains("hbomax") || host.contains("max.com")) keys = new String[]{"com.wbd.stream", "com.hbo.hbonow", "hbomax", "com.hbo"};
        else if (host.contains("roku.com")) keys = new String[]{"com.roku.web.trc", "rokuchannel", "roku"};
        else if (host.contains("plex.tv")) keys = new String[]{"com.plexapp.android", "plexapp", "plex"};
        else if (host.contains("amazon") || host.contains("primevideo")) keys = new String[]{"com.amazon.avod", "com.amazon.firebat", "primevideo", "amazon.avod"};
        else if (host.contains("youtube")) keys = new String[]{"youtube"};
        else return null;

        PackageManager pm = getPackageManager();
        for (String k : keys) {
            for (ApplicationInfo a : pm.getInstalledApplications(0)) {
                if (a.packageName.toLowerCase().contains(k)
                        && (pm.getLaunchIntentForPackage(a.packageName) != null
                            || pm.getLeanbackLaunchIntentForPackage(a.packageName) != null))
                    return a.packageName;
            }
        }
        return null;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_BACK) {
            // Back closes the guide/settings, then turns the TV "off", then leaves the app.
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("(window.hcBack&&hcBack())?'1':'0'", v -> {
                    if (v == null || !v.contains("1")) finish();
                });
            }
            return true;
        }
        if (k == KeyEvent.KEYCODE_MENU) {           // ≡ button = Holler menu (channel keypad, sections, favorites, settings)
            if (e.getAction() == KeyEvent.ACTION_UP)
                web.evaluateJavascript("typeof act==='function'&&act('menu')", null);
            return true;
        }
        if (k == KeyEvent.KEYCODE_GUIDE) {   // remotes with a Guide button
            if (e.getAction() == KeyEvent.ACTION_UP)
                web.evaluateJavascript("typeof act==='function'&&act('guide')", null);
            return true;
        }
        if (k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_CHANNEL_DOWN) {   // Fire TV remotes with channel buttons
            if (e.getAction() == KeyEvent.ACTION_UP)
                web.evaluateJavascript("typeof act==='function'&&act('" + (k == KeyEvent.KEYCODE_CHANNEL_UP ? "up" : "down") + "')", null);
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    private void hideBars() {
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override protected void onResume() {
        super.onResume(); web.onResume(); hideBars(); resumed = true;
        applyPending();
        if (System.currentTimeMillis() - lastCheck > EVERY) checkForUpdates();   // back after a long while: check now
    }
    @Override protected void onPause()  { resumed = false; web.onPause(); super.onPause(); }   // static goes quiet while you watch
    @Override protected void onDestroy() { ui.removeCallbacks(tick); web.destroy(); super.onDestroy(); }
}
