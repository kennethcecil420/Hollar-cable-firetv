package tv.hollercable;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Holler Cable on the Fire Stick: the web app full screen, with the remote wired in. */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                   // remembers channel, favorites, TV settings
        s.setMediaPlaybackRequiresUserGesture(false);   // static + network jingles play right away
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return route(r.getUrl().toString());
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return route(url);
            }
        });

        setContentView(web);
        hideBars();
        web.loadUrl("file:///android_asset/index.html?app=1");   // ?app=1 = power on to the last channel
    }

    /** Every "WATCH" link lands here instead of loading inside the TV. */
    private boolean route(String url) {
        if (url.startsWith("file:") || url.startsWith("about:")) return false;
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "" : u.getHost();
        String path = u.getPath() == null ? "" : u.getPath();

        if (host.endsWith("archive.org") && path.startsWith("/details/")) {
            String id = path.substring("/details/".length()).split("/")[0];
            startActivity(new Intent(this, PlayerActivity.class).putExtra(PlayerActivity.EXTRA_ID, id));
            return true;
        }
        openExternal(u, host);
        return true;
    }

    private void openExternal(Uri u, String host) {
        String pkg = appFor(host);
        if (pkg != null) {
            // 1) ask the service's own app to open the exact title
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            } catch (ActivityNotFoundException ignored) { }
            // 2) at least open the app
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) launch = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
            if (launch != null) {
                startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                Toast.makeText(this, "Opened the app — search for the title there", Toast.LENGTH_LONG).show();
                return;
            }
        }
        // 3) whatever the stick wants to do with the link (usually Silk)
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app on this Fire Stick opens " + host, Toast.LENGTH_LONG).show();
        }
    }

    /** Finds the installed app for a service by name, so exact package IDs don't matter. */
    private String appFor(String host) {
        String[] keys;
        if (host.contains("netflix")) keys = new String[]{"com.netflix.ninja", "netflix"};
        else if (host.contains("peacock")) keys = new String[]{"peacock"};
        else if (host.contains("paramountplus")) keys = new String[]{"paramount", "com.cbs."};
        else if (host.contains("pluto.tv")) keys = new String[]{"pluto"};
        else if (host.contains("tubi")) keys = new String[]{"tubi"};
        else if (host.contains("youtube")) keys = new String[]{"youtube"};
        else return null;

        PackageManager pm = getPackageManager();
        for (String k : keys) {
            for (ApplicationInfo a : pm.getInstalledApplications(0)) {
                if (a.packageName.toLowerCase().contains(k)
                        && (pm.getLaunchIntentForPackage(a.packageName) != null
                            || pm.getLeanbackLaunchIntentForPackage(a.packageName) != null))
                    return a.packageName;
            }
        }
        return null;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_BACK) {
            // Back closes the guide/settings, then turns the TV "off", then leaves the app.
            if (e.getAction() == KeyEvent.ACTION_UP) {
                web.evaluateJavascript("(window.hcBack&&hcBack())?'1':'0'", v -> {
                    if (v == null || !v.contains("1")) finish();
                });
            }
            return true;
        }
        if (k == KeyEvent.KEYCODE_MENU) {           // ≡ button = TV guide
            if (e.getAction() == KeyEvent.ACTION_UP)
                web.evaluateJavascript("typeof act==='function'&&act('guide')", null);
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    private void hideBars() {
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override protected void onResume() { super.onResume(); web.onResume(); hideBars(); }
    @Override protected void onPause()  { web.onPause(); super.onPause(); }   // static goes quiet while you watch
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
