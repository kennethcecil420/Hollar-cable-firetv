package tv.hollercable;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Plays an Internet Archive item right on the TV.
 * Series items keep your place: it picks up at the next episode you haven't watched,
 * and rolls straight into the next one when an episode ends.
 *
 * Remote: OK / Play = pause, ◀ ▶ = previous / next episode, ⏪ ⏩ = skip 30 s, Back = back to Holler Cable.
 */
public class PlayerActivity extends Activity {

    public static final String EXTRA_ID = "id";
    private static final String[] VIDEO = {".ia.mp4", ".mp4", ".m4v", ".mkv", ".webm"};

    private VideoView video;
    private TextView osd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String id, title = "";
    private final List<String> files = new ArrayList<>();
    private int ep;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        id = getIntent().getStringExtra(EXTRA_ID);
        prefs = getSharedPreferences("episodes", MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        video = new VideoView(this);
        root.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        osd = new TextView(this);
        osd.setTextColor(0xFF7DFF8A);
        osd.setTextSize(22);
        osd.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        osd.setShadowLayer(6, 0, 0, Color.BLACK);
        osd.setPadding(48, 32, 48, 32);
        root.addView(osd, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.START));
        setContentView(root);

        video.setOnCompletionListener(mp -> step(+1));
        video.setOnErrorListener((mp, what, extra) -> { show("Can't play this file — trying the next one"); step(+1); return true; });
        video.setOnPreparedListener(MediaPlayer::start);

        show("TUNING IN…");
        new Thread(this::loadItem).start();
    }

    /** Reads the item's file list from archive.org/metadata/ID. */
    private void loadItem() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("https://archive.org/metadata/" + id).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            JSONObject meta = new JSONObject(sb.toString());
            JSONObject md = meta.optJSONObject("metadata");
            if (md != null) title = md.optString("title", id);

            // One playable file per episode: prefer the Archive's own .ia.mp4, then plain .mp4, etc.
            Map<String, String> best = new LinkedHashMap<>();
            Map<String, Integer> rank = new LinkedHashMap<>();
            JSONArray arr = meta.optJSONArray("files");
            for (int i = 0; arr != null && i < arr.length(); i++) {
                String name = arr.getJSONObject(i).optString("name");
                String low = name.toLowerCase();
                if (low.contains("sample") || low.contains("trailer")) continue;
                for (int p = 0; p < VIDEO.length; p++) {
                    if (low.endsWith(VIDEO[p])) {
                        String base = name.substring(0, name.length() - VIDEO[p].length());
                        Integer have = rank.get(base);
                        if (have == null || p < have) { best.put(base, name); rank.put(base, p); }
                        break;
                    }
                }
            }
            files.addAll(best.values());
            Collections.sort(files, PlayerActivity::natural);
            ui.post(() -> {
                if (files.isEmpty()) { show("Nothing playable in this tape — try the next show"); ui.postDelayed(this::finish, 4000); return; }
                ep = Math.min(prefs.getInt(id, 0), files.size() - 1);
                play();
            });
        } catch (Exception e) {
            ui.post(() -> { show("Couldn't reach the Archive. Check the internet and try again."); ui.postDelayed(this::finish, 5000); });
        }
    }

    private void play() {
        String name = files.get(ep);
        prefs.edit().putInt(id, ep).apply();
        String url;
        try {
            url = "https://archive.org/download/" + id + "/" + URLEncoder.encode(name, "UTF-8").replace("+", "%20").replace("%2F", "/");
        } catch (Exception e) { url = "https://archive.org/download/" + id + "/" + name; }
        video.setVideoURI(Uri.parse(url));
        String label = name.replaceAll("\\.(ia\\.)?(mp4|m4v|mkv|webm)$", "");
        show(title + (files.size() > 1 ? "\n" + label + "  (" + (ep + 1) + "/" + files.size() + ")" : ""));
    }

    private void step(int d) {
        if (files.isEmpty()) return;
        int n = ep + d;
        if (n >= files.size()) { prefs.edit().putInt(id, 0).apply(); show("THAT'S THE WHOLE TAPE — back to the cable"); ui.postDelayed(this::finish, 3000); return; }
        ep = Math.max(0, n);
        play();
    }

    private void show(String text) {
        osd.animate().cancel();
        osd.setText(text);
        osd.setAlpha(1f);
        ui.removeCallbacksAndMessages("osd");
        ui.postAtTime(() -> osd.animate().alpha(0f).setDuration(600), "osd", android.os.SystemClock.uptimeMillis() + 5000);
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (video.isPlaying()) { video.pause(); show("❚❚ PAUSED"); } else { video.start(); show("▶ PLAY"); }
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_MEDIA_NEXT: step(+1); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:  case KeyEvent.KEYCODE_MEDIA_PREVIOUS: step(-1); return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: video.seekTo(video.getCurrentPosition() + 30000); show("⏩ +30s"); return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND: video.seekTo(Math.max(0, video.getCurrentPosition() - 30000)); show("⏪ −30s"); return true;
            case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_DPAD_DOWN: case KeyEvent.KEYCODE_INFO:
                show(osd.getText().toString()); return true;
        }
        return super.onKeyDown(k, e);
    }

    @Override protected void onPause() { super.onPause(); video.pause(); }

    /** "Episode 2" before "Episode 10". */
    private static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i, sj = j;
                while (i < a.length() && Character.isDigit(a.charAt(i))) i++;
                while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+(?!$)", ""), nb = b.substring(sj, j).replaceFirst("^0+(?!$)", "");
                if (na.length() != nb.length()) return na.length() - nb.length();
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                int c = Character.toLowerCase(x) - Character.toLowerCase(y);
                if (c != 0) return c;
                i++; j++;
            }
        }
        return (a.length() - i) - (b.length() - j);
    }
}
