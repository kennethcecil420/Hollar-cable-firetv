#!/usr/bin/env python3
"""Holler Cable weekly lineup check.

Looks up every show/movie in the lineup on TMDB's "where to watch" data (US, powered by JustWatch)
and writes availability.json:  titles that left their service ("gone") or moved to another service
Mike has ("moved").  The app reads that file and quietly skips / re-routes those titles.

Usage:  TMDB_KEY=xxxx python3 check_availability.py path/to/index.html availability.json
"""
import json, os, re, sys, time, unicodedata, urllib.parse, urllib.request, datetime

KEY = os.environ.get("TMDB_KEY", "").strip().strip('"').strip()
API = "https://api.themoviedb.org/3"
# TMDB provider names for each Holler Cable service
PROV = {
    "netflix":   ["Netflix", "Netflix Standard with Ads", "Netflix basic with Ads"],
    "hulu":      ["Hulu"],
    "max":       ["HBO Max", "Max", "HBO Max Amazon Channel", "Max Amazon Channel"],
    "peacock":   ["Peacock", "Peacock Premium", "Peacock Premium Plus"],
    "paramount": ["Paramount Plus", "Paramount+", "Paramount Plus Premium", "Paramount Plus Essential", "Paramount+ Amazon Channel", "Paramount Plus Apple TV Channel"],
    "prime":     ["Amazon Prime Video", "Amazon Prime Video with Ads"],
    "tubi":      ["Tubi TV", "Tubi"],
    "pluto":     ["Pluto TV"],
    "plex":      ["Plex", "Plex Channel"],
    "roku":      ["The Roku Channel", "Roku Channel"],
}
ORDER = ["hulu", "max", "netflix", "peacock", "paramount", "prime", "tubi", "pluto", "plex", "roku"]  # where to re-route a moved title
SKIP_TITLES = re.compile(r"movie channel|Yule Log|^Local |Holler|Prevue|Sign-?off|Test Pattern|Color Bars", re.I)

def norm(t):
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    t = re.sub(r"\((19|20)\d\d\)", "", t)          # "Dune (1984)" -> "Dune"
    t = re.sub(r"[^a-z0-9]+", " ", t.lower()).strip()
    return re.sub(r"^the ", "", t)

def year_of(t):
    m = re.search(r"\(((?:19|20)\d\d)\)", t); return int(m.group(1)) if m else None

def extract(html):
    """(title, minutes, service) for every program in the lineup source."""
    s = re.findall(r"<script>(.*?)</script>", html, re.S)[-1]
    q = r"'((?:\\'|[^'])*)'|\"((?:\\\"|[^\"])*)\""
    out = set()
    pats = [
        (r"\bM\((?:%s),(\d+),'(\w+)'" % q, None),
        (r"\[(?:%s),(\d+),'(\w+)'" % q, None),
        (r"\bN\((?:%s)(?:,(\d+))?\)" % q, "netflix"),
        (r"\bK\((?:%s)(?:,(\d+))?\)" % q, "peacock"),
        (r"\bHS\((?:%s)(?:,(\d+))?\)" % q, "hulu"),
        (r"\bHU\((?:%s),'[^']*'(?:,(\d+))?\)" % q, "hulu"),
        (r"\bT\((?:%s),'[^']*'(?:,(\d+))?\)" % q, "tubi"),
    ]
    for pat, svc in pats:
        for m in re.finditer(pat, s):
            t = (m.group(1) or m.group(2) or "").replace("\\'", "'").replace('\\"', '"')
            mins = int(m.group(3) or 30)
            sv = svc or m.group(4)
            if not t or sv not in PROV or mins >= 1000 or SKIP_TITLES.search(t): continue
            out.add((t, sv))
    return sorted(out)

BEARER = len(KEY) > 60 or KEY.startswith("eyJ")   # the long "Read Access Token" works too

def get(path, **params):
    headers = {"accept": "application/json"}
    if BEARER: headers["Authorization"] = "Bearer " + KEY
    else: params["api_key"] = KEY
    url = API + path + "?" + urllib.parse.urlencode(params)
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=20) as r: return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 401: sys.exit("TMDB said the key is wrong (401). Re-copy the API Key from themoviedb.org > Settings > API and save it again as the TMDB_KEY secret, with no spaces.")
            if e.code == 429: time.sleep(2 + attempt * 2); continue
            if e.code == 404: return {}
            raise
        except Exception:
            time.sleep(1 + attempt)
    return {}

def providers_for(title):
    """All US subscription/free provider names for the best exact-title matches, or None if unknown."""
    want, yr = norm(title), year_of(title)
    res = get("/search/multi", query=re.sub(r"\((19|20)\d\d\)", "", title).strip(), include_adult="false").get("results", [])
    hits = [r for r in res if r.get("media_type") in ("movie", "tv") and norm(r.get("title") or r.get("name") or "") == want]
    if yr: hits = [r for r in hits if str(r.get("release_date") or r.get("first_air_date") or "").startswith(str(yr))] or hits
    if not hits: return None
    names, any_data = set(), False
    for r in hits[:3]:
        d = get("/%s/%d/watch/providers" % (r["media_type"], r["id"])).get("results", {}).get("US")
        if not d: continue
        any_data = True
        for k in ("flatrate", "free", "ads"):
            for p in d.get(k, []) or []: names.add(p["provider_name"])
        time.sleep(0.03)
    return names if any_data else None

def svc_has(names, svc): return any(n in names for n in PROV[svc])

def main():
    if not KEY: sys.exit("TMDB_KEY secret is missing")
    src, dst = sys.argv[1], sys.argv[2]
    items = extract(open(src, encoding="utf-8").read())
    cache, gone, moved, unknown, ok = {}, {}, {}, 0, 0
    for i, (t, svc) in enumerate(items):
        if t not in cache: cache[t] = providers_for(t); time.sleep(0.03)
        names = cache[t]
        key = t + "|" + svc
        if names is None: unknown += 1; continue
        if svc_has(names, svc): ok += 1; continue
        alt = next((o for o in ORDER if svc_has(names, o)), None)
        if alt: moved[key] = alt
        else: gone[key] = 1
        if i % 200 == 0: print(i, "/", len(items), flush=True)
    out = {"checked": datetime.date.today().isoformat(), "total": len(items), "ok": ok, "unknown": unknown,
           "gone": gone, "moved": moved}
    json.dump(out, open(dst, "w"), indent=0, sort_keys=True)
    print("checked %d titles: %d ok, %d moved, %d gone, %d not found" % (len(items), ok, len(moved), len(gone), unknown))

if __name__ == "__main__":
    main()
