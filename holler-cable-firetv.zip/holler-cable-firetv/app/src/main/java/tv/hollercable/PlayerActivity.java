package tv.hollercable;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Plays an Internet Archive item right on the TV, using ExoPlayer.
 * ExoPlayer keeps a big buffer, retries dropped connections on its own and picks up at the exact byte
 * where the Archive's server cut off, so movies play all the way through.
 * Series items keep your place: it picks up at the next episode you haven't watched,
 * and rolls straight into the next one when an episode ends. Movies remember where you stopped.
 *
 * Remote: OK / Play = pause, ◀ ▶ = previous / next episode, ⏪ ⏩ = skip 30 s, Back = back to Holler Cable.
 */
public class PlayerActivity extends Activity {

    public static final String EXTRA_ID = "id";
    private static final String[] VIDEO = {".ia.mp4", ".mp4", ".m4v", ".mkv", ".webm"};

    private ExoPlayer player;
    private TextView osd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String id, title = "";
    private final List<String> files = new ArrayList<>();
    private int ep, retries;
    private long bufferingSince;
    private SharedPreferences prefs;
    private static final int MAX_RETRIES = 12;

    /** Watches for a stuck picture, saves your spot, and resets the retry count once things play smoothly. */
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                if (player != null && !files.isEmpty()) {
                    int st = player.getPlaybackState();
                    long pos = player.getCurrentPosition();
                    if (st == Player.STATE_BUFFERING && player.getPlayWhenReady()) {
                        if (bufferingSince == 0) bufferingSince = System.currentTimeMillis();
                        else if (System.currentTimeMillis() - bufferingSince > 25000) { bufferingSince = 0; reconnect(); }
                    } else bufferingSince = 0;
                    if (st == Player.STATE_READY && player.isPlaying()) {
                        if (pos > 60000) retries = 0;
                        prefs.edit().putLong(posKey(), pos).apply();
                    }
                }
            } catch (Exception ignored) { }
            ui.postDelayed(this, 5000);
        }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        id = getIntent().getStringExtra(EXTRA_ID);
        prefs = getSharedPreferences("episodes", MODE_PRIVATE);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000)
                .setReadTimeoutMs(30000)
                .setUserAgent("HollerCable/1.0 (Fire TV)");
        DefaultMediaSourceFactory sources = new DefaultMediaSourceFactory(http)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(20));
        DefaultLoadControl buffer = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(50000, 180000, 2500, 6000)   // keep up to 3 minutes in the tank
                .build();
        player = new ExoPlayer.Builder(this).setMediaSourceFactory(sources).setLoadControl(buffer).build();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        PlayerView view = new PlayerView(this);
        view.setUseController(false);
        view.setKeepScreenOn(true);
        view.setPlayer(player);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        osd = new TextView(this);
        osd.setTextColor(0xFF7DFF8A);
        osd.setTextSize(22);
        osd.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        osd.setShadowLayer(6, 0, 0, Color.BLACK);
        osd.setPadding(48, 32, 48, 32);
        root.addView(osd, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.START));
        setContentView(root);

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_ENDED) {
                    long dur = player.getDuration(), pos = player.getCurrentPosition();
                    // A cut-off connection can look like "the end". If we're nowhere near the real end, reconnect.
                    if (dur > 0 && pos < dur - 45000 && retries < MAX_RETRIES) reconnect();
                    else { prefs.edit().remove(posKey()).apply(); step(+1); }
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                if (retries < MAX_RETRIES) reconnect();
                else { show("Can't play this file — trying the next one"); step(+1); }
            }
        });
        ui.post(watchdog);

        show("TUNING IN…");
        new Thread(this::loadItem).start();
    }

    /** Reads the item's file list from archive.org/metadata/ID. */
    private void loadItem() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("https://archive.org/metadata/" + id).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            JSONObject meta = new JSONObject(sb.toString());
            JSONObject md = meta.optJSONObject("metadata");
            if (md != null) title = md.optString("title", id);

            // One playable file per episode: prefer the Archive's own .ia.mp4, then plain .mp4, etc.
            Map<String, String> best = new LinkedHashMap<>();
            Map<String, Integer> rank = new LinkedHashMap<>();
            JSONArray arr = meta.optJSONArray("files");
            for (int i = 0; arr != null && i < arr.length(); i++) {
                JSONObject f = arr.getJSONObject(i);
                String name = f.optString("name");
                String low = name.toLowerCase();
                if (low.contains("sample") || low.contains("trailer")) continue;
                for (int p = 0; p < VIDEO.length; p++) {
                    if (low.endsWith(VIDEO[p])) {
                        String base = name.substring(0, name.length() - VIDEO[p].length());
                        int r = formatRank(f.optString("format"), f.optString("source")) * 10 + p;
                        Integer have = rank.get(base);
                        if (have == null || r < have) { best.put(base, name); rank.put(base, r); }
                        break;
                    }
                }
            }
            files.addAll(best.values());
            Collections.sort(files, PlayerActivity::natural);
            ui.post(() -> {
                if (files.isEmpty()) { show("Nothing playable in this tape — try the next show"); ui.postDelayed(this::finish, 4000); return; }
                ep = Math.min(prefs.getInt(id, 0), files.size() - 1);
                play();
            });
        } catch (Exception e) {
            ui.post(() -> { show("Couldn't reach the Archive. Check the internet and try again."); ui.postDelayed(this::finish, 5000); });
        }
    }

    private String posKey() { return "pos:" + id + ":" + ep; }

    private void play() {
        String name = files.get(ep);
        prefs.edit().putInt(id, ep).apply();
        String url;
        try {
            url = "https://archive.org/download/" + id + "/" + URLEncoder.encode(name, "UTF-8").replace("+", "%20").replace("%2F", "/");
        } catch (Exception e) { url = "https://archive.org/download/" + id + "/" + name; }
        retries = 0; bufferingSince = 0;
        long resume = prefs.getLong(posKey(), 0);
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)), resume > 60000 ? resume - 5000 : 0);
        player.prepare();
        player.setPlayWhenReady(true);
        String label = name.replaceAll("\\.(ia\\.)?(mp4|m4v|mkv|webm)$", "");
        show(title + (files.size() > 1 ? "\n" + label + "  (" + (ep + 1) + "/" + files.size() + ")" : "")
                + (resume > 60000 ? "\nPICKING UP WHERE YOU LEFT OFF" : ""));
    }

    /** Re-opens the same file at the spot where the picture stopped. */
    private void reconnect() {
        retries++;
        final long at = Math.max(0, player.getCurrentPosition() - 2000);
        show("SIGNAL DROPPED — RECONNECTING… (" + retries + "/" + MAX_RETRIES + ")");
        ui.postDelayed(() -> {
            if (player == null) return;
            player.stop();
            player.prepare();
            player.seekTo(at);
            player.setPlayWhenReady(true);
        }, 1000 + Math.min(retries, 6) * 1000);
    }

    private void step(int d) {
        if (files.isEmpty()) return;
        int n = ep + d;
        if (n >= files.size()) { prefs.edit().putInt(id, 0).apply(); show("THAT'S THE WHOLE TAPE — back to the cable"); ui.postDelayed(this::finish, 3000); return; }
        ep = Math.max(0, n);
        play();
    }

    private void show(String text) {
        osd.animate().cancel();
        osd.setText(text);
        osd.setAlpha(1f);
        ui.removeCallbacksAndMessages("osd");
        ui.postAtTime(() -> osd.animate().alpha(0f).setDuration(600), "osd", android.os.SystemClock.uptimeMillis() + 5000);
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (player.getPlayWhenReady()) { player.setPlayWhenReady(false); show("❚❚ PAUSED"); } else { player.setPlayWhenReady(true); show("▶ PLAY"); }
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_MEDIA_NEXT: prefs.edit().remove(posKey()).apply(); step(+1); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:  case KeyEvent.KEYCODE_MEDIA_PREVIOUS: step(-1); return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: player.seekTo(player.getCurrentPosition() + 30000); show("⏩ +30s"); return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND: player.seekTo(Math.max(0, player.getCurrentPosition() - 30000)); show("⏪ −30s"); return true;
            case KeyEvent.KEYCODE_DPAD_UP: case KeyEvent.KEYCODE_DPAD_DOWN: case KeyEvent.KEYCODE_INFO:
                show(osd.getText().toString()); return true;
        }
        return super.onKeyDown(k, e);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) { if (!files.isEmpty()) prefs.edit().putLong(posKey(), player.getCurrentPosition()).apply(); player.setPlayWhenReady(false); }
    }

    /** The Archive's own H.264 copies stream smoothest on a Fire Stick; big originals (often HEVC/60fps) stall. */
    private static int formatRank(String format, String source) {
        String f = format == null ? "" : format.toLowerCase();
        if (f.equals("h.264 ia")) return 0;
        if (f.equals("h.264")) return 1;
        if (f.contains("512kb")) return 2;
        if ("derivative".equals(source)) return 3;
        if (f.equals("mpeg4")) return 4;
        return 5;
    }

    @Override protected void onDestroy() { ui.removeCallbacksAndMessages(null); if (player != null) { player.release(); player = null; } super.onDestroy(); }

    /** "Episode 2" before "Episode 10". */
    private static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i), y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i, sj = j;
                while (i < a.length() && Character.isDigit(a.charAt(i))) i++;
                while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+(?!$)", ""), nb = b.substring(sj, j).replaceFirst("^0+(?!$)", "");
                if (na.length() != nb.length()) return na.length() - nb.length();
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                int c = Character.toLowerCase(x) - Character.toLowerCase(y);
                if (c != 0) return c;
                i++; j++;
            }
        }
        return (a.length() - i) - (b.length() - j);
    }
}
