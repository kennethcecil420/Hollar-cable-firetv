#!/usr/bin/env python3
"""Holler Cable daily TV listings from Schedules Direct (Gracenote data).

Pulls the next few days of listings for every YouTube TV channel in the lineup and writes guide.json,
which the app reads for real show-by-show listings on those channels.

Usage:  SD_USER=you SD_PASS=secret python3 sd_guide.py path/to/index.html guide.json
Your Schedules Direct account needs a lineup for your area (e.g. DIRECTV + Antenna for ZIP 24740).
"""
import hashlib, json, os, re, sys, time, datetime, urllib.request, unicodedata

API = "https://json.schedulesdirect.org/20141201"
DAYS = 3
UA = "HollerCable/1.0 (personal guide)"

# extra names Gracenote uses for some networks (all compared after normalising)
ALIAS = {
    "fox news": ["fox news channel", "fnc", "foxnews"], "msnbc": ["ms now", "msnbc"], "cnbc world": ["cnbcw"],
    "hgtv": ["home and garden television", "hgtv"], "food network": ["food", "television food network"],
    "discovery": ["discovery channel", "dsc"], "history": ["history channel", "the history channel", "hist"],
    "a e": ["a e network", "aetv", "arts and entertainment"], "national geographic": ["national geographic channel", "natgeo", "ngc"],
    "nat geo wild": ["national geographic wild", "ngwild"], "investigation discovery": ["id", "investigation discovery"],
    "animal planet": ["apl", "animal planet"], "travel channel": ["travel", "trav"], "smithsonian channel": ["smithsonian", "smith"],
    "magnolia network": ["magnolia", "diy network", "diy"], "usa network": ["usa", "usa network"], "comedy central": ["comedy", "cc"],
    "paramount network": ["paramount", "par"], "syfy": ["sci fi", "syfy"], "freeform": ["freeform", "freefrm"], "e": ["e entertainment television", "e!"],
    "tv land": ["tvland"], "we tv": ["wetv", "we"], "own": ["oprah winfrey network", "own"], "bet her": ["bethr", "bet her"],
    "bbc america": ["bbca", "bbc america"], "game show network": ["gsn", "game show network"], "bounce tv": ["bounce"],
    "hallmark channel": ["hallmark", "hall"], "hallmark movies mysteries": ["hmm", "hallmark movies and mysteries"],
    "hallmark family": ["hallmark drama", "hallmark family"], "lifetime": ["life", "lifetime television"], "tcm": ["turner classic movies"],
    "fxm": ["fx movie channel"], "ifc": ["independent film channel"], "sundancetv": ["sundance tv", "sundance"],
    "cmt": ["country music television"], "mtv": ["music television"], "mtv2": ["mtv 2"], "vh1": ["vh 1"],
    "disney channel": ["disney", "disn"], "disney junior": ["disney jr", "dsjr"], "disney xd": ["dxd"], "nickelodeon": ["nick", "nik"],
    "nick jr": ["nick jr", "nickjr"], "nicktoons": ["nicktoon", "nktn"], "teennick": ["teen nick"], "cartoon network": ["toon", "cartoon network adult swim"],
    "espnu": ["espn u"], "espnews": ["espn news"], "sec network": ["secn", "sec"], "acc network": ["accn", "acc"], "big ten network": ["btn", "big ten"],
    "cbs sports network": ["cbssn", "cbs sports"], "fs1": ["fox sports 1"], "fs2": ["fox sports 2"], "nfl network": ["nfln", "nfl"],
    "nba tv": ["nbatv"], "golf channel": ["golf"], "motortrend": ["motor trend", "mtrend", "velocity"], "fox business": ["fox business network", "fbn"],
    "hln": ["headline news"], "newsnation": ["news nation", "wgn america"], "the weather channel": ["weather channel", "twc", "weather"],
    "fox weather": ["foxwx"], "c span": ["cspan"], "c span2": ["cspan2", "c span 2"], "c span3": ["cspan3", "c span 3"],
    "telemundo": ["tele", "telemundo network"], "univision": ["univ"], "unimas": ["unimas", "uni mas"], "universo": ["nbc universo"],
    "trutv": ["tru tv", "tru"], "tnt": ["turner network television"], "tbs": ["tbs superstation"], "amc": ["american movie classics"],
    "oxygen": ["oxygen true crime", "oxyg"], "pop": ["pop tv"], "qvc": ["qvc"], "hsn": ["home shopping network"],
}
LOCAL_AFFIL = {"nbc": "NBC", "abc": "ABC", "cbs": "CBS", "fox": "FOX", "pbs": "PBS", "the cw": "CW", "mynetworktv": "MNT", "ion": "ION"}
PREFER_CALL = {"nbc": ["WVVA"], "abc": ["WOAY"], "cbs": ["WVNS"], "fox": ["WVNSDT2", "WVNS-DT2"], "pbs": ["WSWP", "WVPB"], "the cw": ["WVVADT2", "WVVA-DT2"]}

def norm(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    t = re.sub(r"\b(hd|east|feed)\b$", "", t.strip())
    return re.sub(r"[^a-z0-9]+", " ", t).strip()

def req(method, path, token=None, body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(API + path, data=data, method=method,
        headers={"User-Agent": UA, "Content-Type": "application/json", **({"token": token} if token else {})})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(r, timeout=60) as f: return json.load(f)
        except urllib.error.HTTPError as e:
            msg = e.read().decode(errors="ignore")[:300]
            if e.code in (429, 500, 502, 503) and attempt < 3: time.sleep(5 * (attempt + 1)); continue
            raise SystemExit("Schedules Direct %s %s failed: %s %s" % (method, path, e.code, msg))

def channels(html):
    s = re.findall(r"<script>(.*?)</script>", html, re.S)[-1]
    out = []
    for m in re.finditer(r"\{n:(\d+),name:'((?:\\'|[^'])*)'[^\n]*?kind:'yttv', net:'((?:\\'|[^'])*)'", s):
        out.append((int(m.group(1)), m.group(2).replace("\\'", "'"), m.group(3).replace("\\'", "'")))
    return out

def match(chs, stations):
    by = {}
    for st in stations:
        for k in (st.get("callsign"), st.get("name"), st.get("affiliate") if not (st.get("callsign") or "").startswith(("W", "K")) else None):
            if k: by.setdefault(norm(k), []).append(st)
    found, missing = {}, []
    for n, name, net in chs:
        key = norm(net)
        st = None
        if key in LOCAL_AFFIL:                               # local broadcast stations: match by affiliation, prefer our market's calls
            locs = [x for x in stations if (x.get("affiliate") or "").upper().startswith(LOCAL_AFFIL[key]) and (x.get("callsign") or "")[:1] in "WK"]
            pref = PREFER_CALL.get(key, [])
            locs.sort(key=lambda x: (0 if any((x.get("callsign") or "").replace("-", "").startswith(p.replace("-", "")) for p in pref) else 1))
            st = locs[0] if locs else None
        if not st:
            for k in [key, norm(name)] + [norm(a) for a in ALIAS.get(key, [])]:
                if k in by: st = by[k][0]; break
        if st: found[n] = st["stationID"]
        else: missing.append("%d %s" % (n, name))
    return found, missing

def main():
    user, pw = os.environ.get("SD_USER", "").strip(), os.environ.get("SD_PASS", "")
    if not user or not pw: sys.exit("SD_USER / SD_PASS secrets are missing")
    src, dst = sys.argv[1], sys.argv[2]
    tok = req("POST", "/token", body={"username": user, "password": hashlib.sha1(pw.encode()).hexdigest()})
    token = tok.get("token") or sys.exit("login failed: %s" % tok)
    status = req("GET", "/status", token)
    lineups = [l["lineup"] for l in status.get("lineups", [])]
    if not lineups:
        # SD-JSON lineups live on the account via the API (the website's lineup page is the old XML service), so add them here
        zipc = os.environ.get("SD_ZIP", "24740").strip()
        heads = req("GET", "/headends?country=USA&postalcode=" + zipc, token) or []
        cands = [(h.get("transport", ""), l.get("name", ""), l.get("lineup")) for h in heads for l in h.get("lineups", [])]
        print("lineups available for %s:" % zipc, "; ".join("%s | %s | %s" % c for c in cands))
        want = []
        sat = [c for c in cands if "DIRECTV" in c[1].upper() and "DIRECTV NOW" not in c[1].upper()]
        sat.sort(key=lambda c: (0 if "BLUEFIELD" in c[1].upper() or "BECKLEY" in c[1].upper() else 1, len(c[1])))
        if sat: want.append(sat[0][2])
        ota = [c for c in cands if c[0].lower() in ("antenna", "ota") or "-OTA-" in (c[2] or "")]
        want.append(ota[0][2] if ota else "USA-OTA-" + zipc)
        for lu in want:
            r = req("PUT", "/lineups/" + lu, token)
            print("added lineup", lu, "→", r.get("message", r))
        lineups = want
    stations, seen = [], set()
    for lu in lineups:
        for st in req("GET", "/lineups/" + lu, token).get("stations", []):
            if st["stationID"] not in seen: seen.add(st["stationID"]); stations.append(st)
    chs = channels(open(src, encoding="utf-8").read())
    found, missing = match(chs, stations)
    print("lineups:", lineups, "| stations:", len(stations), "| matched %d of %d channels" % (len(found), len(chs)))
    if missing: print("no listings source for:", ", ".join(missing))
    today = datetime.date.today()
    dates = [(today + datetime.timedelta(days=d)).isoformat() for d in range(-1, DAYS)]
    sids = sorted(set(found.values()))
    sched = []
    for i in range(0, len(sids), 100):
        sched += req("POST", "/schedules", token, [{"stationID": s, "date": dates} for s in sids[i:i + 100]])
    pids = sorted({p["programID"] for d in sched if isinstance(d, dict) for p in d.get("programs", [])})
    progs = {}
    for i in range(0, len(pids), 4000):
        for p in req("POST", "/programs", token, pids[i:i + 4000]):
            if isinstance(p, dict) and p.get("programID"): progs[p["programID"]] = p
    by_sid = {}
    for d in sched:
        if not isinstance(d, dict): continue
        for a in d.get("programs", []):
            s = int(datetime.datetime.fromisoformat(a["airDateTime"].replace("Z", "+00:00")).timestamp())
            p = progs.get(a["programID"], {})
            title = ((p.get("titles") or [{}])[0].get("title120")) or "Programming"
            ep = p.get("episodeTitle150") or ""
            se = ""
            for md in p.get("metadata", []) or []:
                g = md.get("Gracenote")
                if g and g.get("season") and g.get("episode"): se = "S%s E%s" % (g["season"], g["episode"])
            flags = ("L" if a.get("liveTapeDelay") == "Live" else "") + ("N" if a.get("new") else "")
            by_sid.setdefault(d["stationID"], []).append([s, int(a.get("duration", 1800)), title, ep, se, flags])
    out = {"source": "Schedules Direct (Gracenote)", "generated": int(time.time()), "ch": {}, "missing": missing}
    for n, sid in found.items():
        rows = sorted(by_sid.get(sid, []), key=lambda r: r[0])
        if rows: out["ch"][str(n)] = rows
    json.dump(out, open(dst, "w"), separators=(",", ":"))
    print("wrote %s: %d channels, %d listings" % (dst, len(out["ch"]), sum(len(v) for v in out["ch"].values())))

if __name__ == "__main__":
    main()
