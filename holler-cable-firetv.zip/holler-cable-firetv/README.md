# Holler Cable for Fire TV

The Holler Cable web app wrapped as a Fire Stick app: full screen, its own icon, the remote wired in, Archive shows playing right on the TV.

## Remote

| On the TV | Button |
|---|---|
| Channel up / down | ▲ ▼ |
| Guide | ◀ or ≡ (menu) |
| Show info | ▶ |
| Watch what's on | OK or ⏯ |
| Last channel / next favorite | ⏪ / ⏩ |
| Close guide → turn TV off → leave app | Back |

In the Archive player: OK pauses, ◀ ▶ change episode, ⏪ ⏩ skip 30 seconds, Back returns to the cable. Series remember which episode you're on.

## Build it — no computer needed (GitHub)

1. Make a free GitHub account and a new **public** repository called `holler-cable-firetv`.
2. Upload everything in this folder (keep the folder structure, including `.github/workflows/build.yml`).
3. Open the **Actions** tab. The "Build Holler Cable APK" run takes about 5 minutes.
4. The APK ends up at
   `https://github.com/YOUR-NAME/holler-cable-firetv/releases/latest/download/holler-cable.apk`

## Build it — with a computer

Open this folder in Android Studio and pick **Build › Build APK(s)**, or run `gradle :app:assembleRelease`.

## Install on the Fire Stick

1. Settings › My Fire TV › About: click the device name 7 times to unlock **Developer options**.
2. Settings › My Fire TV › Developer options › **Install unknown apps** → turn on **Downloader**.
3. Install **Downloader** (by AFTVnews) from the Appstore, enter the APK link above, and install.
4. Holler Cable shows up under Your Apps. Hold OK on it › Move to put it on the front row.

To update later, run the same Downloader link again — it installs over the old one and keeps your favorites and settings.

## Updating the channel lineup

The lineup lives in `app/src/main/assets/index.html` (the same file as the Holler Cable artifact). Replace it with a newer copy and rebuild.
